Original Authors
----------------

 * [Benjamin Pitzer] (benjamin.pitzer@bosch.com)

Contributors
------------

 * [Russell Toris](http://users.wpi.edu/~rctoris/) (rctoris@wpi.edu)
